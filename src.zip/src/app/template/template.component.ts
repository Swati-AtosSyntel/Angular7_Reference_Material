import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-template',
  templateUrl: './template.component.html'
 
})
export class TemplateComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }
  onSubmit(data){
    alert(data.name);
  }

}
