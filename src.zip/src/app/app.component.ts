import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl:'./app.component.html',
  styleUrls:['./app.component.css']
})
export class AppComponent {
  title = 'Welcome To Angular9!';
  name="Swati";
 show=true;
 hide=true;
 myName={fname:'Aakash',lname:"Patil"};
colors=['red','green','blue','orange']

 }
