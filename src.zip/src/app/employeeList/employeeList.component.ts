import { Component } from '@angular/core';
import { IEmployee } from './employee';
import {EmployeeService} from './employeeService.service';
import {EmployeeCountComponent} from './employeeCount.component';
@Component({
  selector: 'app-employeeList',
  templateUrl: './employeeList.component.html',
  providers:[EmployeeService]
})
export class EmployeeListComponent {
  employees:IEmployee[];
 selectedEmployeeCountRadioButton:string='All';//keeps track of which radio button is selected, to decide which employees to display.
  constructor(private _employeeService:EmployeeService){
    
  }
  ngOnInit(){
    this.employees=this._employeeService.getEmployees();
  }
  getTotalEmployeeCount():number{
    return this.employees.length;
  }
  getMaleEmployeeCount():number{
    return this.employees.filter(e=>e.gender==='Male').length;
  }
  getFemaleEmployeeCount():number{
    return this.employees.filter(e=>e.gender==='Female').length;
  }
  //when radio button is selected ...it will raise custom event and will pass the value of radio 
  //button selected as event data to this function.
  //in .html file this method is given on custom event of child component.
  onEmployeeCountRadioButtonChange(selectedRadioButtonValue:string):void{
    this.selectedEmployeeCountRadioButton=selectedRadioButtonValue;
  }
 
}
