import { Component, Input, Output,EventEmitter } from '@angular/core';


@Component({
  selector: 'app-employeeCount',
  templateUrl: './employeeCount.component.html'

})
export class EmployeeCountComponent {
@Input()
All:number;
 @Input()
Male:number;
@Input()
Female:number;

selectedRadioButtonValue:string='All';//this property keeps track of the value of selected radio button

@Output()
countRadioButtonSelectionChanged:EventEmitter<string>=new EventEmitter<string>();//string value that is selected radio buttoin value to be passed when this event raised.

onRadioButtonSelectionChange(){
    this.countRadioButtonSelectionChanged.emit(this.selectedRadioButtonValue);//raises the custom event and passess the value of radio button selected
    console.log(this.selectedRadioButtonValue);
}

}
