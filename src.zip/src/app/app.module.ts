import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { HttpModule } from '@angular/http';
import {RouterModule,Routes} from '@angular/router';
import {ReactiveFormsModule} from '@angular/forms';
import { AppComponent } from './app.component';
import {EmployeeComponent} from './employee.component';
import {EmployeeTitlePipe} from './employeeTitle.pipe';
import {EmployeeListComponent} from './employeeList/employeeList.component';
import {EmployeeCountComponent} from './employeeList/employeeCount.component';
import {HomeComponent} from './Home/home.component';
import {PageNotFoundComponent} from './PageNotFound/pageNotFound.component';
import {TemplateComponent} from './template/template.component';
import {ReactiveComponent} from './reactive/reactive.component';
const appRoutes:Routes=[
  {path:"home",component:HomeComponent},
  {path:"employees",component:EmployeeListComponent},
  {path:"",redirectTo:'/home', pathMatch:'full'},
  {path:"**",component:PageNotFoundComponent}
]
@NgModule({
  declarations: [
    AppComponent,EmployeeComponent,EmployeeTitlePipe,EmployeeListComponent,EmployeeCountComponent,HomeComponent,PageNotFoundComponent,TemplateComponent,ReactiveComponent
  ],
  imports: [
    BrowserModule,
    FormsModule,
    HttpModule,
    ReactiveFormsModule,
    RouterModule.forRoot(appRoutes)
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
